#!/usr/bin/env python3
#
# Entry point for the Command Line Interface
#
# ------------------------------------------

__all__ = [
    'main',
]

def main():

    """

    CLI Tool for future use

    """

    return ("The CLI is still in production -- we'll figure this out later")

if __name__ == '__main__':
    main()
