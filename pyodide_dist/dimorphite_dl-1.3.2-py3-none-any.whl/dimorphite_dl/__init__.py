from dimorphite_dl.dimorphite_dl import DimorphiteDL

__all__ = ['DimorphiteDL']

__name__ = 'DimorphiteDL'
